#!/bin/bash



time=200
bwnetdef=1000
qsizedef=100
delay=5

iperf_port=5001

#cubic
dir1=cubic
python tcp.py --bw-net $bwnetdef --delay $delay --dir $dir1 --time $time --maxq $qsizedef --cong "cubic"
python plot_queue.py -f $dir1/q.txt -o $dir1/q.png
python plot_ping.py -f $dir1/ping.txt -o $dir1/rtt.png

#bbr
dir2=bbr
python tcp.py --bw-net $bwnetdef --delay $delay --dir $dir2 --time $time --maxq $qsizedef --cong "bbr"
python plot_queue.py -f $dir2/q.txt -o $dir2/q.png
python plot_ping.py -f $dir2/ping.txt -o $dir2/rtt.png

for qsize in 20 100; do
    dir=queue$qsize

    python tcp.py --bw-net $bwnetdef --delay $delay --dir $dir --time $time --maxq $qsize
 
    python plot_queue.py -f $dir/q.txt -o $dir/q.png
    python plot_ping.py -f $dir/ping.txt -o $dir/rtt.png
done

for bw in 1000 100; do
    dir=bw$bw

    python tcp.py --bw-net $bw --delay $delay --dir $dir --time $time --maxq $qsizedef
   
    python plot_queue.py -f $dir/q.txt -o $dir/q.png
    python plot_ping.py -f $dir/ping.txt -o $dir/rtt.png
done

