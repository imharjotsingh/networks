#!/bin/bash

# Note: Mininet must be run as root.  So invoke this shell script
# using sudo.


cd pox && ./pox.py log.level --DEBUG openflow.of_01 forwarding.l2_learning misc.firewall 

