//==============================================================================
// Copyright (C) John-Philip Taylor
// tyljoh010@myuct.ac.za
//
// This file is part of the EEE4084F Course
//
// This file is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>
//
// This is an adaptition of The "Hello World" example avaiable from
// https://en.wikipedia.org/wiki/Message_Passing_Interface#Example_program
//==============================================================================


/** \mainpage Prac4 Main Page
 *
 * \section intro_sec Introduction
 *
 * The purpose of Prac4 is to learn some basics of MPI coding.
 *
 * Look under the Files tab above to see documentation for particular files
 * in this project that have Doxygen comments.
 */



//---------- STUDENT NUMBERS --------------------------------------------------
//
// Please note:  put your student numbers here !!  <<<< NB!  NB!
//
//-----------------------------------------------------------------------------

/* Note that Doxygen comments are used in this file. */
/** \file Prac4
 *  Prac4 - MPI Main Module
 *  The purpose of this prac is to get a basic introduction to using
 *  the MPI libraries for prallel or cluster-based programming.
 */

// Includes needed for the program
#include "Prac4.h"

/** This is the master node function, describing the operations
    that the master will be doing */
void Master () {
 //! <h3>Local vars</h3>
 // The above outputs a heading to doxygen function entry
 int  j;             //! j: Loop counter
 char buff[BUFSIZE]; //! buff: Buffer for transferring message data
 MPI_Status stat;    //! stat: Status of the MPI application

 // Start of "Hello World" example..............................................
 printf("0: We have %d processors\n", numprocs);
 for(j = 1; j < numprocs; j++) {
  sprintf(buff, "Hello %d! ", j);
  MPI_Send(buff, BUFSIZE, MPI_CHAR, j, TAG, MPI_COMM_WORLD);
 }
 for(j = 1; j < numprocs; j++) {
  // This is blocking: normally one would use MPI_Iprobe, with MPI_ANY_SOURCE,
  // to check for messages, and only when there is a message, receive it
  // with MPI_Recv.  This would let the master receive messages from any
  // slave, instead of a specific one only.
  MPI_Recv(buff, BUFSIZE, MPI_CHAR, j, TAG, MPI_COMM_WORLD, &stat);
  printf("0: %s\n", buff);
 }
 // End of "Hello World" example................................................

 // Read the input image
 if(!Input.Read("Data/greatwall.jpg")){
  printf("Cannot read image\n");
  return;
 }

 // Allocated RAM for the output image
 if(!Output.Allocate(Input.Width, Input.Height, Input.Components)) return;

 or(j = 1; j < numprocs; j++) {
     int begin_height = floor((j-1)*Input.Height/(numprocs-1));
     int end_height = floor(j*Input.Height/(numprocs-1));
     int startbuff[3] = {Input.Components, end_height - begin_height+8, Input.Width};

     MPI_Send(startbuff, 3, MPI_INT, j, TAG, MPI_COMM_WORLD);
     
     int BUFSIZE = Input.Components*(end_height - begin_height+8)*Input.Width;
     int *buff = new int[BUFSIZE]; //! buff: Buffer for transferring message data
     int index=0;

    // Inserts the Image data into buffer
     for (int component = 0; component<Input.Components; component++){  
        for (int row = begin_height-4; row<end_height+4; row++){
            for (int column = 0; column<Input.Width; column++){
    if (row<0 || row>=Input.Height)
      buff[index++]=0;
    else  
      buff[index++]=Input.Rows[row][Output.Components*column + component];
            }
        }
     }

     MPI_Send(buff, BUFSIZE, MPI_INT, j, TAG, MPI_COMM_WORLD);
     delete [] buff;
 }

 for(j = 1; j < numprocs; j++) {
  // This is blocking: normally one would use MPI_Iprobe, with MPI_ANY_SOURCE,
  // to check for messages, and only when there is a message, receive it
  // with MPI_Recv.  This would let the master receive messages from any
  // slave, instead of a specific one only.
     int begin_height = floor((j-1)*Input.Height/(numprocs-1));
     int end_height = floor(j*Input.Height/(numprocs-1));
     
     int BUFSIZE = Input.Components*(end_height - begin_height)*Input.Width;
     int *buff= new int[BUFSIZE]; //! buff: Buffer for transferring message data
     int index=0;

    MPI_Recv(buff, BUFSIZE, MPI_INT, j, TAG, MPI_COMM_WORLD, &stat);

    // Inserts the buffer data into Image
     for (int component = 0; component<Input.Components; component++){  
        for (int row = begin_height; row<end_height; row++){
            for (int column = 0; column<Input.Width; column++){
                Output.Rows[row][Output.Components*column + component]=buff[index++];
            }
        }
     }
  delete [] buff;
 }
 // Write the output image
 if(!Output.Write("Data/Output.jpg")){
  printf("Cannot write image\n");
  return;
 }
 //! <h3>Output</h3> The file Output.jpg will be created on success to save
 //! the processed output.
}
//------------------------------------------------------------------------------

/** This is the Slave function, the workers of this MPI application. */
void Slave(int ID){
 MPI_Status stat;

 // receive from rank 0 (master):
 // This is a blocking receive, which is typical for slaves.
 int startbuff [3];
 MPI_Recv(startbuff, 3, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
 
 int BUFSIZE = startbuff[0]*startbuff[1]*startbuff[2];
 int *buff= new int[BUFSIZE];
 MPI_Recv(buff, BUFSIZE, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
 
 // Allocated RAM for the output image
 if(!Input.Allocate(startbuff[2], startbuff[1], startbuff[0])) return;
 if(!Output.Allocate(Input.Width, Input.Height, Input.Components)) return;
 int index=0;
    for (int component = 0; component<Input.Components; component++){  
        for (int row = 0; row<Input.Height; row++){
            for (int column = 0; column<Input.Width; column++){
                Input.Rows[row][Output.Components*column + component] = buff[index++];
            }
        }
    }
 filter();

 delete [] buff;
 
 BUFSIZE = Input.Width*(Input.Height-8)*Input.Components;
 int *buff2= new int[BUFSIZE];
 index=0;
    for (int component = 0; component<Input.Components; component++){  
        for (int row = 4; row<(Input.Height-4); row++){
            for (int column = 0; column<Input.Width; column++){
                buff2[index++]=Output.Rows[row][Output.Components*column + component];
            }
        }
    }
 
 // send to rank 0 (master):
 MPI_Send(buff2, BUFSIZE, MPI_INT, 0, TAG, MPI_COMM_WORLD);
 delete [] buff2;

}
//------------------------------------------------------------------------------

/** This is the entry point to the program. */
int main(int argc, char** argv){
 int myid;

 // MPI programs start with MPI_Init
 MPI_Init(&argc, &argv);

 // find out how big the world is
 MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

 // and this processes' rank is
 MPI_Comm_rank(MPI_COMM_WORLD, &myid);

 // At this point, all programs are running equivalently, the rank
 // distinguishes the roles of the programs, with
 // rank 0 often used as the "master".
 if(myid == 0) Master();
 else          Slave (myid);

 // MPI programs end with MPI_Finalize
 MPI_Finalize();
 return 0;
}
//------------------------------------------------------------------------------

void filter() {
    for (int component = 0; component<Input.Components; component++){
        for (int row = 0; row<Input.Height; row++){
            for (int column = 0; column<Input.Width; column++){
            
                int pixels[81] = {0};
                int index = 0;

                for (int i=-4; i<5; i++){
                    for (int j=-4; j<5; j++){
                        
                        if ( (row+i < 0) || (row+i >= Input.Height) || (column+j < 0) ||  (column+j > Input.Width*Input.Components)){
                            pixels[index++] =0;
                        }
                        else{
                            pixels[index++] = Input.Rows[row+i][Input.Components*(column+j) + component];
                        }
                    }
                }

                Output.Rows[row][Output.Components*column + component] = quick_median(pixels, 0, 81);
                
            }
            
        }
    }
    return;
}

int quick_median(int arr[], int left, int right) {
      int i = left, j = right;
      int tmp;
      int pivot = arr[(left + right) / 2];

      /* partition */
      while (i <= j) {
            while (arr[i] < pivot)
                  i++;
            while (arr[j] > pivot)
                  j--;
            if (i <= j) {
                  tmp = arr[i];
                  arr[i] = arr[j];
                  arr[j] = tmp;
                  i++;
                  j--;
            }
      };

      /* recursion */
      if (left < j)
            quick_median(arr, left, j);
      if (i < right)
            quick_median(arr, i, right);

      return arr[40];
}
