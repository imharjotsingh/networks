var searchData=
[
  ['slave',['Slave',['../Prac4_8cpp.html#a3cdafe41bdc98a25ea63a3697c1edc84',1,'Prac4.cpp']]]
];
